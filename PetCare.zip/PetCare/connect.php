<?php
  $con=mysqli_connect("localhost:3308","root","","contact") or die(mysqli_error($con));
  //echo "YEs";
?>
